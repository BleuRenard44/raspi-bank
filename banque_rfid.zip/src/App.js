// App.js
import React, { useState } from "react";
import "./App.css";

const api = "http://raspberrypi.local:8000";

function App() {
  const [account, setAccount] = useState({ prenom: "", nom: "", adresse: "" });
  const [uid, setUid] = useState("");
  const [accountCreated, setAccountCreated] = useState(false);
  const [status, setStatus] = useState({ create: "", write: "", recharge: "", buy: "" });
  const [recharge, setRecharge] = useState({ uid: "", amount: "" });
  const [purchase, setPurchase] = useState({ uid: "", productId: "" });
  const [products, setProducts] = useState([]);

  // Gestion des formulaires
  const handleAccountChange = e => setAccount({ ...account, [e.target.name]: e.target.value });
  const handleRechargeChange = e => setRecharge({ ...recharge, [e.target.name]: e.target.value });
  const handlePurchaseChange = e => setPurchase({ ...purchase, [e.target.name]: e.target.value });

  // 1. Scan carte pour lire UID
  const scanCard = async () => {
    setStatus({ ...status, create: "Lecture de la carte..." });
    try {
      const res = await fetch(api + "/scan_uid");
      const data = await res.json();
      setUid(data.uid);
      setStatus({ ...status, create: `UID détecté : ${data.uid}` });
    } catch {
      setStatus({ ...status, create: "Erreur lors de la lecture de la carte." });
    }
  };

  // 2. Création du compte avec l'UID
  const createAccount = async e => {
    e.preventDefault();
    if (!uid) {
      setStatus({ ...status, create: "Veuillez scanner la carte d'abord." });
      return;
    }
    const res = await fetch(api + "/accounts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...account, rfid_uid: uid }),
    });
    const data = await res.json();
    setStatus({ ...status, create: JSON.stringify(data) });
    setAccountCreated(true);
  };

  // 3. Écriture des infos sur la carte
  const writeCard = async () => {
    setStatus({ ...status, write: "Écriture sur la carte..." });
    try {
      const res = await fetch(api + "/write_card", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rfid_uid: uid,
          nom: account.nom,
          prenom: account.prenom,
          solde: 0,
          banque: "Banque RFID"
        }),
      });
      const data = await res.json();
      setStatus({ ...status, write: JSON.stringify(data) });
    } catch {
      setStatus({ ...status, write: "Erreur lors de l'écriture sur la carte." });
    }
  };

  // Reste des fonctionnalités
  const rechargeCard = async e => {
    e.preventDefault();
    const res = await fetch(`${api}/accounts/${recharge.uid}/recharge`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ montant: parseFloat(recharge.amount) }),
    });
    setStatus({ ...status, recharge: JSON.stringify(await res.json()) });
  };

  const getProducts = async () => {
    const res = await fetch(api + "/products");
    setProducts(await res.json());
  };

  const purchaseProduct = async e => {
    e.preventDefault();
    const res = await fetch(api + "/purchase", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rfid_uid: purchase.uid, product_id: parseInt(purchase.productId) }),
    });
    setStatus({ ...status, buy: JSON.stringify(await res.json()) });
  };

  return (
    <div className="container">
      <h1>💳 Banque RFID</h1>
      <form className="section" onSubmit={createAccount}>
        <h2>Créer une carte</h2>
        <input name="prenom" placeholder="Prénom" value={account.prenom} onChange={handleAccountChange} />
        <input name="nom" placeholder="Nom" value={account.nom} onChange={handleAccountChange} />
        <input name="adresse" placeholder="Adresse" value={account.adresse} onChange={handleAccountChange} />
        <div style={{ display: "flex", gap: "1em", marginBottom: "1em" }}>
          <button type="button" onClick={scanCard}>1. Scanner la carte</button>
          <span style={{ alignSelf: "center" }}>{uid && `UID: ${uid}`}</span>
        </div>
        <button type="submit" disabled={!uid}>2. Créer le compte</button>
        <div className="status">{status.create}</div>
      </form>
      {accountCreated && (
        <div className="section">
          <button onClick={writeCard}>3. Écrire les infos sur la carte</button>
          <div className="status">{status.write}</div>
        </div>
      )}
      <form className="section" onSubmit={rechargeCard}>
        <h2>Recharger une carte</h2>
        <input name="uid" placeholder="UID RFID" value={recharge.uid} onChange={handleRechargeChange} />
        <input name="amount" type="number" placeholder="Montant" value={recharge.amount} onChange={handleRechargeChange} />
        <button type="submit">Recharger</button>
        <div className="status">{status.recharge}</div>
      </form>
      <div className="section">
        <h2>Produits</h2>
        <button type="button" onClick={getProducts}>Lister les produits</button>
        <ul>
          {products.map(item => (
            <li key={item.id}>#{item.id} - {item.name} ({item.price}€)</li>
          ))}
        </ul>
      </div>
      <form className="section" onSubmit={purchaseProduct}>
        <h2>Effectuer un achat</h2>
        <input name="uid" placeholder="UID RFID" value={purchase.uid} onChange={handlePurchaseChange} />
        <input name="productId" type="number" placeholder="ID Produit" value={purchase.productId} onChange={handlePurchaseChange} />
        <button type="submit">Acheter</button>
        <div className="status">{status.buy}</div>
      </form>
    </div>
  );
}

export default App;